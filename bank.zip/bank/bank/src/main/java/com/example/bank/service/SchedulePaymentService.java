package com.example.bank.service;

import com.example.bank.model.Schedule;
import com.example.bank.repository.ScheduleRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Service;
 
@Service
public class SchedulePaymentService {
 
    @Autowired
    private ScheduleRepository scheduleRepository;
 
    @Autowired
    private KafkaTemplate<String, Object> kafkaTemplate;
 
    public Schedule createSchedule(Schedule schedule) {
        schedule.setStatus("Pending");
        Schedule savedSchedule = scheduleRepository.save(schedule);
 
        // Send to Kafka
        kafkaTemplate.send("scheduled-payments", savedSchedule);
 
        return savedSchedule;
    }
}