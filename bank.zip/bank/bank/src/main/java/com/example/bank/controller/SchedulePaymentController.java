package com.example.bank.controller;

import com.example.bank.model.Schedule;
import com.example.bank.service.SchedulePaymentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
 
@RestController
@RequestMapping("/api/schedule")
public class SchedulePaymentController {
 
    @Autowired
    private SchedulePaymentService schedulePaymentService;
 
    @PostMapping("/create")
    public String createSchedule(@RequestBody Schedule schedule) {
        Schedule createdSchedule = schedulePaymentService.createSchedule(schedule);
        return "Schedule created with ID: " + createdSchedule.getPaymentId();
    }
}
