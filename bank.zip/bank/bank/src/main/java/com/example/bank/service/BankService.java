package com.example.bank.service;

import com.example.bank.model.Account;
import com.example.bank.model.User;
import com.example.bank.repository.AccountRepository;
import com.example.bank.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
 
import java.time.LocalDateTime;
import java.util.UUID;
 
@Service
public class BankService {
 
    @Autowired
    private UserRepository userRepository;
 
    @Autowired
    private AccountRepository accountRepository;
 
    public User registerUser(User user) {
        User savedUser = userRepository.save(user);
 
        // Automatically generate an account for the user
        Account account = new Account();
        account.setUserId(savedUser.getUserId());
        account.setAccountType("Savings"); // Example type
        account.setBalance(0.0);
        account.setBankName("CITI"); // Set your bank name
        account.setIfscCode("BANK2024"); // Example IFSC code
        account.setCreatedAt(LocalDateTime.now());
        account.setAccountNumber(generateAccountNumber());
 
        accountRepository.save(account);
 
        return savedUser;
    }
 
    private String generateAccountNumber() {
        return UUID.randomUUID().toString().replace("-", "").substring(0, 12); // Example generation logic
    }
}
