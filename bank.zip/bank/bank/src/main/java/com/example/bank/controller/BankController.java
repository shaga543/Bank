package com.example.bank.controller;

import com.example.bank.model.ApiResponse;
import com.example.bank.model.User;
import com.example.bank.service.BankService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
 
@RestController
@RequestMapping("/api/bank")
public class BankController {
 
    @Autowired
    private BankService bankService;
 
    @PostMapping("/register")
    public ApiResponse registerUser(@RequestBody User user) {
    	User registeredUser = bankService.registerUser(user);
    //public User registerUser(@RequestBody User user) {
    	return new ApiResponse("Account created successfully", registeredUser);
        //return bankService.registerUser(user);
    }
}
