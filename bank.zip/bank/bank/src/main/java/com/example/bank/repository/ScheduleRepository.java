package com.example.bank.repository;

import org.springframework.data.mongodb.repository.MongoRepository;

import com.example.bank.model.Schedule;

public interface ScheduleRepository extends MongoRepository<Schedule, String> {

}
